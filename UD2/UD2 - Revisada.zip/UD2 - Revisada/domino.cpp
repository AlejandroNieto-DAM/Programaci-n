#include <iostream>
using namespace std;

int main()
{
    
    int i = 0, b = 0, c = 0;
    
    for(i = 0; i <= 6; i++)
    {
        
        for (b = c; b <= 6; b++)
        {
            cout << i << " " << b << endl;
        }
        
        c++;
        
    }
}
