#include <iostream>
using namespace std;

int main ()
{
    
    for(int i=0; i<=10; i++)
    {
        cout << "7 x " << i << " = " << 7*i << endl;
    }
}

