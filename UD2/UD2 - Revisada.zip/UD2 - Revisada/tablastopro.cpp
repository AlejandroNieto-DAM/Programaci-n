#include <iostream>
using namespace std;

int main()
{
    for(int i = 0; i <= 10; i++)
    {
        for(int b = 0; b <= 10; b++)
        {
            cout << i << " x " << b << " = " << i*b << endl;
        }
        
        cout << endl;
    }
}
