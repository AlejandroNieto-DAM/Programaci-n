#include <iostream>
using namespace std;

int main()
{
    int cuenta = 0;
    
    while(cuenta < 10)
    {
        cout << "No debo copiar en clase." << endl;
        cuenta++;
    }
}
