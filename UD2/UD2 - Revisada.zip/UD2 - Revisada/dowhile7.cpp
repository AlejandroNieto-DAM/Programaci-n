#include <iostream>
using namespace std;

int main ()
{
    int contador = 0;
    
    do
    {
        cout << "7 x " << contador << " = " << 7*contador << endl;
        contador ++;
    }
    while(contador <= 10);
    
}
