#include <iostream>
using namespace std;

int main()
{
    int cuenta = 1;
    
    do {
        cout << "No debo copiar en clase." << endl;
        cuenta = cuenta + 1;
    } while (cuenta <= 10);
    
}
