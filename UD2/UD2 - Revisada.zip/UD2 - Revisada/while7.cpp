#include <iostream>
using namespace std;

int main()
{
    int i = 0;
    
    while( i < 10 )
    {
        i++;
        cout << " 7 x " << i << " = " << 7*i << endl;
    }
}
